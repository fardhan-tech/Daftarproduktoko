package kelas.model;

public class Produk {

    private final String kode;
    private final String nama;
    private final String kategori;
    private final double harga;

    public Produk(String kode, String nama, String kategori, double harga) {
        if (kode == null || kode.isBlank()) {
            throw new IllegalArgumentException("Kode produk wajib diisi.");
        }

        if (nama == null || nama.isBlank()) {
            throw new IllegalArgumentException("Nama produk wajib diisi.");
        }

        if (kategori == null || kategori.isBlank()) {
            throw new IllegalArgumentException("Kategori wajib dipilih.");
        }

        if (harga <= 0 || Double.isNaN(harga) || Double.isInfinite(harga)) {
            throw new IllegalArgumentException("Harga harus lebih dari nol.");
        }

        this.kode = kode;
        this.nama = nama.trim();
        this.kategori = kategori;
        this.harga = harga;
    }

    public String getKode() {
        return kode;
    }

    public String getNama() {
        return nama;
    }

    public String getKategori() {
        return kategori;
    }

    public double getHarga() {
        return harga;
    }
}